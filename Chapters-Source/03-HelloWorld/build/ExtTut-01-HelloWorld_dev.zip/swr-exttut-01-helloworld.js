/*global define,require,window,console,_ */
/*jslint    devel:true,
            white: true
 */
define([
        'jquery',
        'underscore',
        './exttut-01-helloworld-properties',
        './exttut-01-helloworld-initialproperties',
        'text!./lib/css/style.css'
],
function ($, _, props, initProps, cssContent) {
    'use strict';

    $("<style>").html(cssContent).appendTo("head");

    return {

        definition: props,
        initialProperties: initProps,

        snapshot: { canTakeSnapshot: true },

        paint: function ($element, layout) {

            $element.empty();
            var $helloWorld = $(document.createElement('div'));
            $helloWorld.addClass('hello-world');
            $helloWorld.html('Hello World from the extension "01-ExtTut-HelloWorld"');
            $element.append($helloWorld);

        }
    };
});