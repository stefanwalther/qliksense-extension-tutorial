/*global define*/
define( [], function () {
    return {
        qHyperCubeDef: {
            qDimensions: [],
            qMeasures: [],
            qInitialDataFetch: [
                {
                    qWidth: 2,
                    qHeight: 50
                }
            ]
        }
    }
} )